var mysql = require("mysql");


var db = mysql.createConnection ( {
host : "localhost",
user:"root",
password:'',
database:"korcul_tarifler"
});


db.connect();
module.exports = db;