var express = require('express');
var router = express.Router();
var db = require("../models/db");
var bodyParser = require("body-parser");
var urlencodedParser = bodyParser.urlencoded({ extended: false })
var session = require("express-session");
var md5 = require("md5");
var html2text = require("html2plaintext");
var ucwords = require("ucwords"); 







// GET home page.


//Kullanıcı için yönlendirme tanımlamaları

router.get("/",function(req,res,next){
let sorgu = "select * from korcul_tarifler";
db.query(sorgu,function(err,rows){
if(err) throw err;
res.render("index",{title:"Son yüklenen körcül tarifler-Akdeniz Üniversitesi",data:rows});
});
});


router.get("/fakultelere_gore_korcul_tarifler",function(req,res,next){
let sorgu = "select * from korcul_tarifler where kategori like'%Fakülteler%'";
db.query(sorgu,function(err,rows){
if(err) throw err;
res.render("fakultelere_gore_korcul_tarifler",{title:"Fakültelere göre körcül tarifler-Akdeniz Üniversitesi",data:rows});
});
}); 



router.get("/idari_birimlere_gore_korcul_tarifler",function(req,res,next){
let sorgu = "select * from korcul_tarifler where kategori like'%İdari birimler%'";
db.query(sorgu,function(err,rows){
if(err) throw err;
res.render("idari_alanlara_gore_korcul_tarifler",{title:"İdari alanlara göre körcül tarifler-Akdeniz Üniversitesi",data:rows});
});
});


router.get("/sosyal_alanlara_gore_korcul_tarifler",function(req,res,next){
let sorgu = "select * from korcul_tarifler where kategori like'%Sosyal alanlar%'";
db.query(sorgu,function(err,rows){
if(err) throw err;
res.render("sosyal_alanlara_gore_korcul_tarifler",{title:"Sosyal alanlara göre körcül tarifler-Akdeniz Üniversitesi",data:rows});
});
});
 
router.get("/tum_korcul_tarifler",function(req,res,next){
let sorgu = "select * from korcul_tarifler";
db.query(sorgu,function(err,rows){
if(err) throw err;
res.render("tum_korcul_tarifler",{title:"Tüm körcül tarifler-Akdeniz Üniversitesi",data:rows});
});
});


router.get("/tarif_goruntule/:id",function(req,res,next){
let sorgu = "select * from korcul_tarifler where id=?";
let id = [
req.params.id
];
db.query(sorgu,id,function(err,rows){
if(err) throw err;

for(i = 0;i < rows.length;i++)
{
var data = rows[i].bitis_noktasi;
var details = html2text(rows[i].korcul_tarif);
}

res.render("korcul_tarif_detaylari",{title:data+" "+"hedifine tarif detayları",data:rows,details: details,});

});
});


router.post("/arama",function(req,res,next){
let sorgu = "select * from korcul_tarifler where bitis_noktasi =?  ";
let aranan_terim =[
ucwords(req.body.ara)
];
db.query(sorgu,aranan_terim,function(err,results){
if(err) throw err;
res.render("arama",{title:"Arama sonuçları",data:results});


});
});

//Yönetim paneli yönlendirmeleri

router.get("/admin/giris",function(req,res,next){
	var d = new Date();
	res.render("admin/giris",{title:"Körcül tarif yönetim paneli",date:d.getFullYear()});
	
	
});
router.post("/admin/kontrol",urlencodedParser,function(req,res,next){
	
	var user = "admin";
	var pass = md5("!!@kt@!!");
	
	if(req.body.kullaniciadi == user && md5(req.body.kullanicisifre) == pass){
		req.session.giris = "true";
		res.redirect("/admin/panel");
	}
	else
	{
		res.redirect("/admin/giris");
	}
});


//Yönetici paneli için yönlendirmeler

router.get('/admin/panel', function(req, res, next) {
  if(req.session.giris=="true"){
var d  = new Date();
let sorgu = "select *from  korcul_tarifler";
db.query(sorgu,function(err,rows){
         req.flash('error', err); 
         res.render('admin/panel',{title:"Körcül tarifler",data:rows,date:d.getFullYear()});   
});
  }
  else
{
	res.redirect("/admin/giris");
}

});





router.get("/admin/fakultelere_gore_korcul_tarifler",function(req,res,next){
	if(req.session.giris=="true"){
		var d = new Date();
let sorgu = "select * from korcul_tarifler where kategori like '%Fakülteler%'";
db.query(sorgu,function(err,rows){
	req.flash('error',err);
	res.render("admin/fakultelere_gore_korcul_tarifler",{title:"Fakültelere göre körcül tarifler",
	data:rows,
	date:d.getFullYear()
	});
});
	}
	else
	{
		res.redirect("/admin/giris");
	}
	});


router.get("/admin/sosyal_alanlara_gore_korcul_tarifler",function(req,res,next){
	if(req.session.giris=="true"){
		var d = new Date();
	let sorgu = "select * from korcul_tarifler where kategori like '%Sosyal alanlar%'";
	db.query(sorgu,function(err,rows){
		req.flash('error',err);
		res.render("admin/sosyal_alanlara_gore_korcul_tarifler",{
			title:"Sosyal alanlara göre körcül tarifler",
			data:rows,
			date:d.getFullYear()
			});
	
	
	});
	}
else
{
	res.redirect("/admin/giris");
}

	});


router.get("/admin/idari_birimlere_gore_korcul_tarifler",function(req,res,next){
	if(req.session.giris == "true"){
		var d = new Date();
	let sorgu = "select * from korcul_tarifler where kategori like '%İdari alanlara göre körcül tarifler%'";
	db.query(sorgu,function(err,rows){
		req.flash('errors',err);
		res.render("admin/idari_alanlara_gore_korcul_tarifler",{
			title:"İdari alanlara göre körcül tarifler",
			data:rows,
			date:d.getFullYear()
					});
		
	});
	}
	else
	{
		res.redirect("/admin/giris");
	}
		});


router.get("/admin/yeni_tarif_ekle",function(req,res,next){
	if(req.session.giris == "true"){
		var d = new Date();
var d = new Date();

res.render("admin/yeni_tarif",{title:"Yeni körcül tarif",date:d.toLocaleString(),message:"",date:d.getFullYear()});	

}
else
{
	res.redirect("/admin/giris");
}

});

router.post("/admin/yeni_tarif_ekle",urlencodedParser,function(req,res,next){
if(req.session.giris == "true"){
var d = new Date();
let sorgu = "INSERT INTO korcul_tarifler VALUES(NULL,?,?,?,?,?,?)";
let veriler =[
req.body.baslangic_noktasi,
req.body.bitis_noktasi,
req.body.tarif_kategorisi,
req.body.korcul_tarif,
req.body.hazirlayan,
req.body.olusturulma_zamani
];

db.query(sorgu,veriler,function(err,results){
	req.flash("error",err);
	res.render("admin/yeni_tarif",{title:" Veri başarıyla eklendi",message:"Yeni tarif eklendi",date:d.toLocaleString()});
});	
	

}
else
{
	res.redirect("/admin/giris");
}
});



router.get("/admin/tarif_duzenle/(:id)",function(req,res,next){
if(req.session.giris == "true"){	
var d = new Date();

let sorgu = "select * from korcul_tarifler where id = ?";
let veri =[
req.params.id
];


db.query(sorgu,veri,function(err,results){
	if(err) throw err;
	res.render("admin/tarif_duzenle",{title:"Tarif düzenle",data:results,date:d.getFullYear()});
	
});
}
else
{
	res.redirect("/admin/giris");
}
});




router.post("/admin/tarif_duzenle",urlencodedParser,function(req,res,next){
	if(req.session.giris == "true"){
		var d = new Date();
	let sorgu = "update korcul_tarifler set baslangic_noktasi = ?,bitis_noktasi = ?, kategori = ?, korcul_tarif = ?, hazirlayan = ?, olusturulma_zamani = ? where id="+req.body.id;
	let veriler = [
	req.body.baslangic_noktasi,
	req.body.bitis_noktasi,
	req.body.tarif_kategorisi,
	req.body.korcul_tarif,
	req.body.hazirlayan,
	req.body.olusturulma_zamani
];
	
	
	db.query(sorgu,veriler,function(err,results){
	if(err) throw err;
res.redirect("/admin/panel");	
		
	});
	}
	else
{
	res.redirect("/admin/giris");
}
	});


module.exports = router;
